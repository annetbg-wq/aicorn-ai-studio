export const APP_CONFIG = {
  name: 'Atlas Clinic Ops',
  tagline: 'Deterministic smoke build.',
  freeActionLimit: 10,
  storagePrefix: 'smoke.v1',
} as const;

export const STORAGE_KEYS = {
  profile: 'smoke.v1.profile',
  theme: 'smoke.v1.theme',
  feed: 'smoke.v1.feed',
  progress: 'smoke.v1.progress',
} as const;
