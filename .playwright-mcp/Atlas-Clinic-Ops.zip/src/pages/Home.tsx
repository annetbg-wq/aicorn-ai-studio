import { useState } from 'react';

export default function Home() {
  const [n, setN] = useState(0);
  return (
    <div style={{ padding: 24, minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16 }}>
      <h1 data-testid="project-title">Atlas Clinic Ops</h1>
      <p>{n}</p>
      <button type="button" onClick={() => setN(v => v + 1)}>Go</button>
    </div>
  );
}
