import { useState } from 'react';

export default function Onboarding() {
  const [done, setDone] = useState(false);
  if (done) return <p>Ready!</p>;
  return (
    <div style={{ padding: 24 }}>
      <h1>Atlas Clinic Ops — Onboarding</h1>
      <button type="button" onClick={() => setDone(true)}>Get Started</button>
    </div>
  );
}
