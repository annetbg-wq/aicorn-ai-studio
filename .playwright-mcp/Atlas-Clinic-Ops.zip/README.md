# Atlas Clinic Ops

A React + TypeScript + Vite application.

## Quick start

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Stack

- React 18
- TypeScript 5
- Vite 5
- Tailwind CSS
